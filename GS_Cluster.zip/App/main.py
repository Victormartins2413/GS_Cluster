from flask import Blueprint, request, jsonify, render_template
from concurrent.futures import ThreadPoolExecutor
from .models import PollutionData, db

main_bp = Blueprint('main', __name__)
executor = ThreadPoolExecutor(max_workers=10)

@main_bp.route('/Inicial')
def index():
    return render_template('Site.html')

@main_bp.route('/data', methods=['GET', 'POST'])
def data():
    if request.method == 'POST':
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid data"}), 400

        executor.submit(save_data, data)
        return jsonify({"message": "Data received successfully"}), 202
    elif request.method == 'GET':
        pollution_data = {
            "temperature": {
                "value": 26.3,
                "unit": "C"
            },
            "dissolved_oxygen": {
                "value": 6.4,
                "unit": "mg/L"
            },
            "salinity": {
                "value": 35.1,
                "unit": "ppt"
            },
            "turbidity": {
                "value": 3.5,
                "unit": "NTU"
            },
            "microplastics": {
                "value": 150,
                "unit": "particles/m^3"
            }
        }

        return jsonify(pollution_data)

def save_data(data):
    new_data = PollutionData(
        sensor_id=data['sensor_id'],
        timestamp=data['timestamp'],
        pollution_level=data['pollution_level'],
        city=data['city'],
        state=data['state'],
        country=data['country']
    )
    db.session.add(new_data)
    db.session.commit()
