import requests

data = {
    "sensor_id": "sensor_123",
    "timestamp": "2024-06-01T12:00:00Z",
    "pollution_level": 45.0,
    "city": "São Paulo",
    "state": "São Paulo",
    "country": "Brasil",
    "api_key": "YOUR_API_KEY"
}

response = requests.post("http://localhost:5000/data", json=data)
print(response.json())
